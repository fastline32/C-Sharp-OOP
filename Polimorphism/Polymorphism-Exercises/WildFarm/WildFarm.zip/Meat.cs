﻿namespace WildFarm
{
    public class Meat : Food ,IFood
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}