﻿namespace WildFarm
{
    public class Seeds : Food, IFood
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}