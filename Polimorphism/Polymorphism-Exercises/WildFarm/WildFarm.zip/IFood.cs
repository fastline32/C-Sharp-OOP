﻿namespace WildFarm
{
    public interface IFood
    {
        public int Quantity { get; set; }
    }
}