﻿namespace FoodShortage.Interfaces
{
    public interface IIdent
    {
        public string Name { get; }
        public int Age { get; }
    }
}