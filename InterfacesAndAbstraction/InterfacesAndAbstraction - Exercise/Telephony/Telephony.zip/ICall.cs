﻿using System.Text;

namespace Telephony
{
    public interface ICall
    {
        public string Call(string number);
    }
}