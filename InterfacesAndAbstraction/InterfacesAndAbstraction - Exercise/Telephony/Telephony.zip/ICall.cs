﻿namespace Telephony
{
    public interface ICall
    {
        public void Call(string number);
    }
}