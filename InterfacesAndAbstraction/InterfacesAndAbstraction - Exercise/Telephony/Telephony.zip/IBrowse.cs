﻿namespace Telephony
{
    public interface IBrowse
    {
        public string Browsing(string url);
    }
}