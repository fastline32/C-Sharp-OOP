﻿namespace Telephony
{
    public interface IBrowse
    {
        public void Browsing(string url);
    }
}