﻿namespace BirthdayCelebrations.Interfaces
{
    public interface IIdent
    {
        public string Birthday { get; }
    }
}