﻿using BirthdayCelebrations.Core;

namespace BirthdayCelebrations
{
    internal class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
