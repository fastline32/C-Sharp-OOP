﻿namespace MilitaryElite.Interfaces
{
    public interface IRepair
    {
        public string PartName { get; set; }
        public int HourWorked { get; set; }
    }
}