﻿namespace MilitaryElite.Interfaces
{
    public interface ISpy : ISoldier
    {
        public string CodeNumber { get; set; }
    }
}