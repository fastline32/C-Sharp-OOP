﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddCollection<T>
    {
        public int Add(T element);
    }

}