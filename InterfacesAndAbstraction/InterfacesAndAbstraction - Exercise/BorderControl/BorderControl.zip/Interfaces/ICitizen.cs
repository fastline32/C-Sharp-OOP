﻿namespace BorderControl.Interfaces
{
    public interface IIdent
    {
        public string Id { get; }
    }
}